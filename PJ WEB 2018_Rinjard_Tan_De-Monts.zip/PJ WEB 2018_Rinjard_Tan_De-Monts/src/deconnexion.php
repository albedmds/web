<?php
echo "<script>
alert('Deconnecté');
window.location.href='page.html';  
</script>";;
	?>